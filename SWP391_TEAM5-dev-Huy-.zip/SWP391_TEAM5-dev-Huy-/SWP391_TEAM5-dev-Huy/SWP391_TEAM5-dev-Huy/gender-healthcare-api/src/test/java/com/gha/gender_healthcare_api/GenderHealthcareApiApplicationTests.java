package com.gha.gender_healthcare_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenderHealthcareApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
